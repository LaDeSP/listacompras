package controller;

public class Constantes {
	
	public static String LocalDs = "LocalDAO";
	public static String AdministradorDs = "AdmDAO";
	public static String ClienteDs = "ClienteDAO";
	public static String MasterDs = "MasterDAO";
	public static String ProdutoDs = "produtoDAO";
	public static String SupermercadoDs = "SupermercadoDAO";
	public static String PrecoDs = "PrecoDAO";
	public static String PromocaoDs = "PromocaoDAO";
	public static String HistoricoCDs = "HistoricoClienteDAO";
	public static String ListaDeProdutoDs = "ListaDeProdutpDAO";
	public static int Cliente = 1;
	public static int Administrador = 2;
	public static int Master = 3;
	public static int Usuario = 4;
}
