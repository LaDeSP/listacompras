package controller;

public class HistoricoPromocaoDAO extends DAO{

	/**
	 * @param args
	 */
	

}
