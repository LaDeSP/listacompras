package view;

import java.util.Scanner;

public class ViewListadeProdutos {
	
	Scanner entrada = new Scanner(System.in);
	
	public ViewListadeProdutos()
	{
		
	}

}
